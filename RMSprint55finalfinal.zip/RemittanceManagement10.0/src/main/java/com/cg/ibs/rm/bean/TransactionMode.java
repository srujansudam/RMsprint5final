package com.cg.ibs.rm.bean;

public enum TransactionMode {
	ONLINE,CASH
}
