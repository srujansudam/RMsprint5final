package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.rm.bean.AccountBean;
import com.cg.ibs.rm.exception.IBSExceptions;

public interface AccountService {
	
	public Set<AccountBean> getAccountsOfUci(BigInteger uci) throws IBSExceptions;
}
